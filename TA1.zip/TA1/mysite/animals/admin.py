from django.contrib import admin

from .models import Animal,Action

admin.site.register(Animal)
admin.site.register(Action)